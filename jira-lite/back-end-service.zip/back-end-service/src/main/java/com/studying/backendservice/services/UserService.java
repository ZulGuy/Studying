package com.studying.backendservice.services;

import com.studying.backendservice.dto.UserDTO;
import java.util.List;

public interface UserService {

  List<UserDTO> searchUsers(String query);
  UserDTO getUserById(int id);

}
