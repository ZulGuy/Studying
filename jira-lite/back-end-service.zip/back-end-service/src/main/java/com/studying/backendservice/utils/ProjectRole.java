package com.studying.backendservice.utils;

public enum ProjectRole {
  VIEWER, EDITOR, ADMIN
}
