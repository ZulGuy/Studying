package com.studying.backendservice.dto;

public class TaskDTO {
  public int id;
  public String summary;
  public String description;
  public String status;
  public Integer assigneeId;
  public Integer initiatorId;
}

