package com.studying.backendservice.controllers;

import com.studying.backendservice.models.Comment;
import com.studying.backendservice.services.CommentService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/comments")
public class CommentController {

  private final CommentService commentService;

  @Autowired
  public CommentController(CommentService commentService) {
    this.commentService = commentService;
  }

  @PostMapping
  public ResponseEntity<Comment> addComment(@RequestBody Comment comment) {
    return ResponseEntity.ok(commentService.addComment(comment));
  }

  @GetMapping("/task/{taskId}")
  public ResponseEntity<List<Comment>> getComments(@PathVariable int taskId) {
    return  ResponseEntity.ok(commentService.getCommentsForTask(taskId));
  }

  @DeleteMapping("/{id}")
  public void deleteComment(@PathVariable int id) {
    commentService.deleteComment(id);
  }

  @PutMapping("/{id}")
  public ResponseEntity<Comment> updateComment(@PathVariable int id, @RequestBody Comment comment) {
    Comment updatedComment = commentService.updateComment(id, comment);
    return ResponseEntity.ok(updatedComment);
  }

  @GetMapping("/{id}")
  public ResponseEntity<Comment> getCommentById(@PathVariable int id) {
    return ResponseEntity.ok(commentService.getCommentById(id));
  }

}
