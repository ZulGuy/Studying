package com.studying.backendservice.controllers;

import com.studying.backendservice.dto.TaskDTO;
import com.studying.backendservice.models.Task;
import com.studying.backendservice.repositories.UserRepository;
import com.studying.backendservice.services.TaskService;
import com.studying.backendservice.utils.Status;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

  private final TaskService taskService;
  private final UserRepository userRepository;

  @Autowired
  public TaskController(TaskService taskService, UserRepository userRepository) {
    this.taskService = taskService;
    this.userRepository = userRepository;
  }

  @PostMapping
  public ResponseEntity<Task> createTask(@RequestBody Task task) {
    return ResponseEntity.ok(taskService.createTask(task));
  }

  @GetMapping("/{id}")
  public ResponseEntity<Task> getTask(@PathVariable int id) {
    return ResponseEntity.ok(taskService.getTaskById(id));
  }

  @PutMapping("/{id}")
  public ResponseEntity<Task> updateTask(@PathVariable int id, @RequestBody TaskDTO dto) {
    Task task = taskService.getTaskById(id);
    task.setSummary(dto.summary);
    task.setDescription(dto.description);
    task.setStatus(Status.valueOf(dto.status));

    if (dto.assigneeId != null) {
      task.setAssignee(userRepository.findById(dto.assigneeId).orElse(null));
    }

    return ResponseEntity.ok(taskService.updateTask(task));
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<Void> deleteTask(@PathVariable int id) {
    taskService.deleteTask(id);
    return ResponseEntity.ok().build();
  }

  @GetMapping("/project/{projectId}")
  public ResponseEntity<List<TaskDTO>> getTasksForProject(@PathVariable int projectId) {
    List<TaskDTO> dtos = taskService.getTasksForProject(projectId).stream()
        .map(this::toDto)
        .toList();
    return ResponseEntity.ok(dtos);
  }
  private TaskDTO toDto(Task task) {
    TaskDTO dto = new TaskDTO();
    dto.id = task.getId();
    dto.summary = task.getSummary();
    dto.description = task.getDescription();
    dto.status = task.getStatus().name();

    if (task.getAssignee() != null) {
      dto.assigneeId = task.getAssignee().getId();
    }

    if (task.getInitiator() != null) {
      dto.initiatorId = task.getInitiator().getId();
    }

    return dto;
  }

}
