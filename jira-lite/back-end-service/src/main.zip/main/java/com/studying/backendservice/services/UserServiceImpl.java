package com.studying.backendservice.services;

import com.studying.backendservice.dto.UserDTO;
import com.studying.backendservice.models.User;
import com.studying.backendservice.repositories.UserRepository;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

  private final UserRepository userRepository;

  @Autowired
  public UserServiceImpl(UserRepository userRepository) {
    this.userRepository = userRepository;
  }

  @Override
  public List<UserDTO> searchUsers(String query) {
    return userRepository.findByUsernameContainingIgnoreCase(query)
        .stream()
        .map(this::toDto)
        .collect(Collectors.toList());
  }

  @Override
  public UserDTO getUserById(int id) {
    return userRepository.findById(id)
        .map(this::toDto)
        .orElseThrow();
  }

  @Override
  public List<User> getAllUsers() {
    return userRepository.findAll();
  }

  @Override
  public void delete(int id) {
    userRepository.deleteById(id);
  }

  @Override
  public void update(UserDTO user) {
    User updatedUser = userRepository.findById(user.getId()).orElseThrow();
    updatedUser.setUsername(user.getName());
    updatedUser.setEmail(user.getEmail());
    updatedUser.setEnabled(user.isActive());
    userRepository.save(updatedUser);
  }

  @Override
  public void save(UserDTO user) {
    User userEntity = new User();
    userEntity.setUsername(user.getName());
    userEntity.setEmail(user.getEmail());
    userRepository.save(userEntity);
  }

  @Override
  public UserDTO toDto(User user) {
    UserDTO dto = new UserDTO();
    dto.setId(user.getId());
    dto.setName(user.getUsername());
    dto.setEmail(user.getEmail());
    dto.setActive(user.isEnabled());
    dto.setRole(user.getRole());
    return dto;
  }
}
