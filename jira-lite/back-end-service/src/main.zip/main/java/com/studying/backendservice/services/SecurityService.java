package com.studying.backendservice.services;

import com.studying.backendservice.models.User;
import com.studying.backendservice.repositories.ProjectUserRepository;
import com.studying.backendservice.utils.ProjectRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("securityService")
public class SecurityService {

  @Autowired
  private ProjectUserRepository projectUserRepository;

  public boolean canAccessUsers(int projectId, User principal) {
    return principal.getRole().name().equals("ROLE_ADMIN");
  }

  public boolean canManageProject(int projectId, User principal) {
    // 1. Системний адміністратор (User.getRole() == ADMIN)
    if (principal.getRole().name().equals("ROLE_ADMIN")) return true;

    // 2. Проектна роль ADMIN
    return projectUserRepository
        .findByProjectIdAndUserId(projectId, principal.getId())
        .map(pu -> pu.getRoles().contains(ProjectRole.ADMIN))
        .orElse(false);
  }
}
