import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProjectService } from '../../services/project.service';

@Component({
  selector: 'app-project-detail',
  template: `
    <div *ngIf="project">
      <h3>{{ project.name }}</h3>
      <p>{{ project.description }}</p>
      <!-- тут можна додати секцію для задач та коментарів -->
    </div>
  `
})
export class ProjectDetailComponent implements OnInit {
  project: any;
  constructor(
    private route: ActivatedRoute,
    private projectService: ProjectService
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.projectService.getById(Number(id)).subscribe({
      next: (data) => this.project = data,
      error: () => this.project = null
    });
  }
}
