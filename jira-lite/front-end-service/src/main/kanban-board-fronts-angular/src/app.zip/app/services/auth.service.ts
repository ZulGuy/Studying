import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import {tap} from "rxjs/operators";
import {UserDTO} from "../types/api.types";

@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = `${environment.apiUrl}/api/auth`;
  public redirectUrl: string | null = null;
  private user: UserDTO & { role: string } | null = null;

  constructor(private http: HttpClient) {}

  setCurrentUser(user: UserDTO & { role: string }) {
    this.user = user;
  }

  getCurrentUser() {
    return this.user;
  }

  login(credentials: { username: string, password: string }): Observable<any> {
    return this.http.post<{ token: string }>(`${this.api}/login`, credentials, { withCredentials: true }).pipe(
      tap(response => {
        localStorage.setItem('token', response.token); // ← збереження
      })
    );
  }

  logout(): Observable<any> {
    return this.http.post(`${this.api}/logout`, {}, { withCredentials: true });
  }

  isAuthenticated(): boolean {
    const token = localStorage.getItem('token'); // або from cookie
    if (!token) return false;

    // опціонально перевірити expiration, якщо зберігаєш `exp` з JWT
    return true;
  }
}
