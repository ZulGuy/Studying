import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { ProjectService } from '../../services/project.service';
import { RecentProjectService } from '../../services/recent-project.service';
import { ProjectDTO } from "../../types/api.types";

@Component({
  selector: 'app-projects-list',
  templateUrl: './projects-list.component.html',
  styleUrls: ['./projects-list.component.scss']
})
export class ProjectsListComponent implements OnInit {
  projects: ProjectDTO[] = [];

  constructor(
    private projectService: ProjectService,
    private recentProjectService: RecentProjectService,
    private router: Router
  ) {}

  ngOnInit() {
    this.projectService.getAll().subscribe(data => this.projects = data);
  }

  openProject(project: ProjectDTO) {
    this.recentProjectService.setRecentProject({
      id: String(project.id),
      name: project.name,
      description: project.description
    });

    this.router.navigate(['/projects', project.id]);
  }
}
