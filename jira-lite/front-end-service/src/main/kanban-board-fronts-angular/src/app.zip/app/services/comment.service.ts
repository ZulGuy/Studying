import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { CommentDTO } from '../types/api.types';

@Injectable({ providedIn: 'root' })
export class CommentService {
  private api = `${environment.apiUrl}/api/comments`;

  constructor(private http: HttpClient) {}

  getByTaskId(taskId: number): Observable<CommentDTO[]> {
    return this.http.get<CommentDTO[]>(`${this.api}/task/${taskId}`, { withCredentials: true });
  }

  addComment(taskId: number, description: string): Observable<CommentDTO> {
    // task:{id: taskId} — бо бекенд чекає обʼєкт, не просто id
    return this.http.post<CommentDTO>(
      this.api,
      { task: { id: taskId }, description },
      { withCredentials: true }
    );
  }
}
