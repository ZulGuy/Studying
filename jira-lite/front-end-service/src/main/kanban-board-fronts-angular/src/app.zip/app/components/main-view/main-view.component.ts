import { Component, OnInit } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { ProjectService } from '../../services/project.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TaskDTO, TaskStatus } from '../../types/api.types';
import {Column} from "../../models/column.model";
import {TaskService} from "../../services/task.service";

@Component({
  selector: 'app-main-view',
  templateUrl: './main-view.component.html',
  styleUrls: ['./main-view.component.scss']
})
export class MainViewComponent implements OnInit {
  board = {
    name: '',
    columns: [
      { name: 'TODO', tasks: [] as TaskDTO[] },
      { name: 'IN_PROGRESS', tasks: [] as TaskDTO[] },
      { name: 'DONE', tasks: [] as TaskDTO[] }
    ]
  };

  projectId!: number;

  constructor(
    private projectService: ProjectService,
    private route: ActivatedRoute,
    private router: Router,
    private taskService: TaskService
  ) {}

  ngOnInit(): void {
    this.route.parent?.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.projectId = +id;
        this.loadProject();
        this.loadTasks();
      }
    });
  }


  drop(event: CdkDragDrop<TaskDTO[]>, newStatus: TaskStatus) {
    const task = event.previousContainer.data[event.previousIndex];

    // Якщо статус не змінився — нічого не робимо
    if (task.status === newStatus) return;

    const previousList = event.previousContainer.data;
    const currentList = event.container.data;

    const previousIndex = event.previousIndex;

    // Тимчасово змінюємо статус
    task.status = newStatus;

    // Надсилаємо запит на бекенд
    this.taskService.updateTask(task).subscribe({
      next: () => {
        // Успішно — переносимо
        transferArrayItem(previousList, currentList, previousIndex, event.currentIndex);
      },
      error: () => {
        // Якщо не вдалось — повертаємо статус назад
        task.status = event.previousContainer.id.toUpperCase() as TaskStatus;
      }
    });
  }



  openTask(task: TaskDTO) {
    this.router.navigate(['/task', task.id]);
  }

  loadProject() {
    this.projectService.getById(this.projectId).subscribe(project => {
      this.board.name = project.name;
    });
  }

  loadTasks() {
    this.taskService.getTasksForProject(this.projectId).subscribe(tasks => {
      const columnsMap: Record<string, TaskDTO[]> = {
        TODO: [],
        IN_PROGRESS: [],
        DONE: []
      };

      for (const task of tasks) {
        const status = task.status || 'TODO';
        if (columnsMap[status]) {
          columnsMap[status].push(task);
        }
      }

      this.board.columns = [
        new Column('TODO', columnsMap.TODO),
        new Column('IN_PROGRESS', columnsMap.IN_PROGRESS),
        new Column('DONE', columnsMap.DONE)
      ];
    });
  }


}
